package org.locadora.modelo;

public interface EntidadeBase {
    Integer getId();
}